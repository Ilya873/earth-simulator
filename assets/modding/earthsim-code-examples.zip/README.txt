Earth Simulator — примеры дополнений с кодом / code add-on examples (2.2.0)

RU: распакуйте папки в папку mods рядом с игрой, поставьте галочки в «Мастерской» и перезапустите игру.
    Описание каждого примера: https://ilya873.github.io/earth-simulator/modding/recipes/

EN: unpack the folders into the mods folder next to the game, tick them in «Workshop» and restart the game.
    What each example does: https://ilya873.github.io/earth-simulator/en/modding/recipes/
