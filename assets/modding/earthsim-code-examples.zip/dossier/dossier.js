// dossier.js — своя вкладка на странице державы и своя команда, меняющая мир (работает и в сетевой игре)
(function () {
  'use strict';
  const E = s => UI.esc(String(s));   // всё из мира (имена держав, городов) — в разметку только через UI.esc
  let host = null;                    // элемент вкладки

  // 1. Команда. Всё, что меняет мир по нажатию кнопки, идёт через netAct/netDo: вне комнаты netDo — обычный вызов,
  //    в комнате команда уходит ведущему и выполняется у всех игроков в один и тот же момент.
  //    Аргументы приходят из сети — проверяйте их
  netAct('dossier_feast', function (uid) {
    if (!Number.isInteger(uid)) return;
    const st = stateByUid(uid); if (!st) return;
    if (!(st.treasury > 0)) return;     // пустая казна — праздника не будет
    st.treasury *= 0.9;                 // праздник стоит десятую часть казны
    st.stability = Math.min(1, st.stability + 0.05);
    logEvent('peace', TF('{0} устраивает всенародный праздник', '{0} holds a festival for all its people', st.name), { s: [st.id], cell: st.capital, imp: 1 });
  });

  // 2. Вкладка страницы державы: build(h) — один раз, разметка; update(st, r, force) — при каждой перерисовке страницы
  statsAddStateTab({
    id: 'dossier', icon: 'book', before: 'chron', dead: false,
    label: function () { return T('Досье', 'Dossier'); },
    build: function (h) {
      host = h;
      h.innerHTML = "<div class='ui-kpis' data-d='kpi'></div><p class='ui-muted' data-d='note' style='margin:10px 0'></p>" +
        "<button class='ui-btn' data-d='feast'></button>";
      h.querySelector('[data-d=feast]').addEventListener('click', function () {
        const uid = +h.dataset.uid; if (uid >= 0) netDo('dossier_feast', uid);
      });
    },
    init: function () {},
    update: function (st) {
      if (!host || !st) return;
      host.dataset.uid = st.uid;
      let n = 0, coast = 0, tSum = 0, hiI = -1, hiV = -1;
      for (const i of st.cells) {   // st.cells — Set номеров клеток державы
        n++; if (W.isCoast[i]) coast++;
        tSum += W.tempSmoothed[i];
        const h = landH(i); if (h > hiV) { hiV = h; hiI = i; }
      }
      const k = (label, val) => "<div class='ui-kpi'><b>" + E(val) + '</b><span>' + E(label) + '</span></div>';
      host.querySelector('[data-d=kpi]').innerHTML =
        k(T('Клеток земли', 'Land cells'), UI.fmt(n)) +
        k(T('Средняя температура', 'Mean temperature'), n ? uTemp(tSum / n) : '—') +
        k(T('Высшая точка', 'Highest point'), hiI >= 0 ? uM(hiV * 5000, 10) : '—') +
        k(T('Побережье', 'Coastline'), n ? Math.round(coast / n * 100) + ' %' : '—');
      const cap = st.capital >= 0 ? (cityName(st.capital) || placeNameAt(st.capital) || '—') : '—';
      host.querySelector('[data-d=note]').textContent = TF('Столица — {0}. Казна: {1}.', 'Capital: {0}. Treasury: {1}.', cap, UI.fmt(Math.round(st.treasury)));
      const b = host.querySelector('[data-d=feast]');
      b.textContent = T('Устроить праздник', 'Hold a festival');
      b.title = T('Десятая часть казны — и стабильность выше', 'A tenth of the treasury for more stability');
    },
  });
})();
