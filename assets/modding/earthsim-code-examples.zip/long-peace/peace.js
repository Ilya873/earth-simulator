// peace.js — «Долгий мир»: первые сто лет войн не бывает, на сотый год хроника подводит итог
(function () {
  'use strict';
  const ID = 'long-peace';     // id дополнения: подпись обёртки и ключ в сохранении
  const UNTIL = 100;           // до какого года мира войн нет
  let stopped = 0;             // сколько войн не началось (хранится в сохранении)

  // Обёртка над функцией игры. declareWar(att, def, cause, force) возвращает войну или null, если войны не будет.
  // force — войну объявляет сам игрок (инструмент «Война»): его волю не трогаем, держим только ИИ
  ModAPI.wrap('declareWar', function (orig, att, def, cause, force) {
    if (!force && W.simYear < UNTIL) { stopped++; return null; }
    return orig(att, def, cause, force);
  }, ID);

  ModAPI.on('year', function (y) {
    if (y !== UNTIL) return;
    logEvent('peace', TF('Долгий мир окончен. Попыток начать войну за {0} лет: {1}',
      'The Long Peace is over. Attempts to start a war in {0} years: {1}', UNTIL, stopped), { imp: 2 });
  });

  // своё состояние: новый мир — с нуля, сохранение — в o.ext[ID]
  ModAPI.on('worldgen', function () { stopped = 0; });
  ModAPI.on('reset', function () { stopped = 0; });
  ModAPI.on('save', function (o) { o.ext[ID] = { stopped: stopped }; });
  ModAPI.on('load', function (o) {
    const d = o.ext && o.ext[ID];  // раздела нет — старое сохранение или мир без дополнения
    stopped = d && d.stopped > 0 ? d.stopped | 0 : 0;
  });
})();
