// jubilees.js — свой вид записей хроники: юбилеи держав (каждые 100 лет)
(function () {
  'use strict';
  // Вид записи: категория фильтра хроники (war, state, people, mind, nature, econ, player), значок UI.icon,
  // заголовок уведомления, good: 1 — событие хорошее (зелёное). Имя вида — латинские строчные буквы
  chronKind('jubilee', {
    cat: 'state', icon: 'crown', good: 1,
    title: function () { return T('Юбилей державы', 'A nation’s jubilee'); },
  });

  // Шаг мира: событие 'year' приходит внутри шага, поэтому писать в хронику здесь можно (и в сетевой игре тоже)
  ModAPI.on('year', function (y) {
    for (const st of states) {
      if (!st.alive) continue;
      const age = y - Math.floor(st.born);
      if (age <= 0 || age % 100 !== 0) continue;
      logEvent('jubilee', TF('{0} празднует {1} лет со дня основания', '{0} celebrates {1} years since its founding', st.name, age),
        { s: [st.id], cell: st.capital, imp: age >= 300 ? 2 : 1 });   // s — державы записи (кнопка «Показать»), imp 2 — уведомление на экране
    }
  });
})();
