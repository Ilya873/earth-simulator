// deaths.js — people.js зовёт deathsHook в начале _pDie (правка по якорю в mod.json):
// весь people.js спрятан в замыкание, и обёрткой ModAPI до этой функции не добраться
(function () {
  'use strict';
  const ID = 'deaths-patch';
  let byCause = {};   // причина → сколько людей за этот век

  window.deathsHook = function (p, cause, year) {
    if (!p || p.died !== null) return;   // уже мёртв — игра ничего не сделает, не считаем
    const c = cause || 'other';
    byCause[c] = (byCause[c] || 0) + 1;
  };
  ModAPI.on('year', function (y) {
    if (y % 100 !== 0) return;
    const top = Object.keys(byCause).sort(function (a, b) { return byCause[b] - byCause[a]; }).slice(0, 3);
    if (top.length) {
      const name = function (k) { return typeof causeName === 'function' ? causeName(k) : k; };
      logEvent('people', TF('Итог века: чаще всего умирали — {0}', 'The century in sum: most deaths were — {0}',
        top.map(function (k) { return tLower(name(k)) + ' (' + byCause[k] + ')'; }).join(', ')), { imp: 1 });
    }
    byCause = {};
  });
  ModAPI.on('worldgen', function () { byCause = {}; });
  ModAPI.on('reset', function () { byCause = {}; });
  ModAPI.on('save', function (o) { o.ext[ID] = { c: byCause }; });
  ModAPI.on('load', function (o) { const d = o.ext && o.ext[ID]; byCause = d && d.c && typeof d.c === 'object' ? d.c : {}; });
})();
