// politics.js — три способа изменить жизнь держав: слагаемое стабильности, политический множитель, обёртка «после»
(function () {
  'use strict';
  const ID = 'harbor-politics';

  // 1. Слагаемое стабильности: fn(st) возвращает добавку к цели стабильности (в пределах ±0.3).
  //    Строка сама появляется в разборе стабильности (подсказка у стабильности на странице державы).
  //    fn — чистая функция мира: только читает, ничего не пишет и не тянет Math.random
  civStabTerm('harbor', 'Столица-гавань', 'Harbour capital', function (st) {
    return st.capital >= 0 && W.isCoast[st.capital] ? 0.04 : 0;
  });

  // 2. Политические множители: st.pm = { tech, growth, gdp, lit, war, mil, … — множители (1 — без изменений);
  //    stab, happy — добавки (0 — без изменений) }. Игра сама держит итог в разумных пределах
  window.POL_PM_HOOKS = window.POL_PM_HOOKS || [];
  POL_PM_HOOKS.push(function (st, m) {
    if (st.gov !== 'theocracy') return;
    m.growth *= 1.05;   // больше детей
    m.tech *= 0.92;     // меньше учёных
  });

  // 3. Обёртка «после»: powerOf(st) — военная сила державы; вернули число — это новый результат
  ModAPI.after('powerOf', function (power, st) {
    return st && st.gov === 'theocracy' && st.piety > 0.8 ? power * 1.15 : power;
  }, ID);
})();
