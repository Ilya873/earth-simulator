// top.js — своя кнопка на верхней панели и своё окно с таблицей
(function () {
  'use strict';
  let table = null;

  function rows() {
    return states.filter(function (s) { return s.alive; }).map(function (s) {
      return { uid: s.uid, name: s.name, pop: Math.round(s.pop), area: s.area, era: s.era, stab: s.stability };
    });
  }
  function open() {
    // UI.win(id, o): окно создаётся один раз по id; потом его только показывают и перерисовывают
    const w = UI.win('top-nations', { title: T('Крупнейшие державы', 'Largest nations'), width: 640 });
    if (!table) {
      table = UI.table(w.body, {
        sortKey: 'pop', sortDir: -1, limit: 30, rows: [],
        onRow: function (r) { const st = stateByUid(r.uid); if (st) openStateDetail(st); },
        cols: [
          { key: 'name', label: T('Держава', 'Nation') },
          { key: 'pop', label: T('Население', 'Population'), num: 1, fmt: function (v) { return UI.fmt(v); } },
          { key: 'area', label: T('Клеток', 'Cells'), num: 1 },
          { key: 'era', label: T('Эпоха', 'Era'), num: 1, fmt: function (v) { return UI.esc(eraName(v)); } },
          { key: 'stab', label: T('Стабильность', 'Stability'), num: 1, fmt: function (v) { return Math.round(v * 100) + ' %'; } },
        ],
      });
    }
    table.setRows(rows());
    w.show();
  }
  // окно перерисовываем по событию мира, а не каждый кадр
  ModAPI.on('year', function () { const w = UI.win('top-nations'); if (table && w.isOpen()) table.setRows(rows()); });

  // кнопка на верхней панели — рядом с числом войн
  ModAPI.ready(function () {
    const box = document.getElementById('stat-wars-box'); if (!box) return;
    const b = document.createElement('div');
    b.className = 'stat'; b.id = 'stat-top-nations'; b.style.cursor = 'pointer';
    b.title = T('Крупнейшие державы мира', 'The largest nations of the world');
    b.innerHTML = '<span class="v">' + UI.icon('crown', 15) + '<span>' + UI.esc(T('топ', 'top')) + '</span></span>';
    b.addEventListener('click', open);
    box.parentNode.insertBefore(b, box.nextSibling);
  });
})();
