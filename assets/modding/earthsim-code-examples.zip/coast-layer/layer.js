// layer.js — свой слой карты «До моря»: и в 2D, и в 3D, с легендой и строкой в подсказке у курсора
(function () {
  'use strict';
  const FAR = 16;   // с какого расстояния (в клетках) земля считается совсем «глубинной»
  // цвета легенды: берег — голубой, середина — жёлтый, глубь — тёмно-красный
  const C0 = [64, 170, 235], C1 = [240, 214, 110], C2 = [168, 58, 40];
  const mix = (a, b, t, k) => Math.round(a[k] + (b[k] - a[k]) * t);

  registerLayer('coastdist', {
    label: T('До моря', 'To the sea'),     // подпись кнопки внизу экрана и плашки на карте
    group: 'nature',                        // ряд кнопок «Природа» ('society' — «Общество»)
    legend: { g: 'linear-gradient(90deg,rgb(64,170,235),rgb(240,214,110),rgb(168,58,40))',
              mn: T('берег', 'coast'), mx: TF('{0}+ клеток', '{0}+ cells', FAR) },
    // цвет клетки i: out = [r, g, b, a], всё 0..255; a = 0 — клетка прозрачна (море видно как есть)
    cell(i, out) {
      if (W.isWater[i]) { out[3] = 0; return; }
      const t = Math.min(1, W.distOcean[i] / FAR);
      const a = t < 0.5 ? C0 : C1, b = t < 0.5 ? C1 : C2, u = t < 0.5 ? t * 2 : t * 2 - 1;
      out[0] = mix(a, b, u, 0); out[1] = mix(a, b, u, 1); out[2] = mix(a, b, u, 2); out[3] = 200;
    },
    smooth: true,       // плавно между клетками (поле), а не резкими квадратами
    veil: true,         // приглушить биомы под слоем
    borders: true,      // границы держав поверх
    info(i) {           // строка в подсказке у курсора
      return W.isWater[i] ? '' : TF('До моря: {0} кл.', 'To the sea: {0} cells', W.distOcean[i]);
    },
  });
})();
