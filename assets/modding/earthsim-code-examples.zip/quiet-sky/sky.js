// sky.js — обёртка «перед» (отменить вызов функции игры) и событие бедствия
(function () {
  'use strict';
  const ID = 'quiet-sky';

  // before: fn получает аргументы функции игры; вернула false — функция игры не вызывается.
  // disasterTrigger(type, cell, power, byPlayer): byPlayer — бедствие вызвал игрок своим инструментом
  ModAPI.before('disasterTrigger', function (type, cell, power, byPlayer) {
    if ((type === 'meteor' || type === 'asteroid') && !byPlayer) return false;
  }, ID);

  // Событие 'disaster' (d, type, cell, byPlayer) — бедствие уже ударило. Здесь только показываем:
  // всплывающее сообщение — это интерфейс, а не мир, поэтому netRemote() и язык игрока тут не важны
  ModAPI.on('disaster', function (d, type, cell, byPlayer) {
    if (byPlayer || !(cell >= 0)) return;
    const id = W.stateId[cell], st = id >= 0 ? states[id] : null;
    if (!st || !st.alive || st.capital !== cell) return;
    UI.toast({ title: T('Бедствие у столицы', 'Disaster at a capital'), icon: 'warn', type: 'war',
      text: TF('{0}: беда пришла в столицу', '{0}: disaster has struck the capital', st.name),
      onClick: function () { focusCell(cell); }, action: T('Показать', 'Show') });
  });
})();
