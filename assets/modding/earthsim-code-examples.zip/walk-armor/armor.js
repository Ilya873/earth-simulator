// armor.js — прогулка от первого лица: события (урон, победа, обыск), своё табло и своя клавиша
(function () {
  'use strict';
  let worn = true, wins = 0;

  function hud() {
    wkHudSet('mailarmor', '<b>' + UI.esc(worn ? T('Кольчуга надета', 'Mail on') : T('Без кольчуги', 'No mail')) + '</b><br>' +
      UI.esc(TF('Побед: {0}', 'Victories: {0}', wins)));
  }
  // урон игроку: вернули число — это новый урон
  ModAPI.walkOn('hurt', function (dmg, why) { return worn ? dmg * 0.67 : dmg; });
  // кто-то повержен; by === 'player' — рукой игрока
  ModAPI.walkOn('kill', function (victim, by) { if (by === 'player') { wins++; hud(); } });
  // обыск тела: out.msgs — строки «Найдено: …», out.ammo — патроны по видам, out.wpn — оружие
  ModAPI.walkOn('loot', function (npc, out) { if (Math.random() < 0.5) out.msgs.push(T('записка с картой', 'a note with a map')); });
  // табло обновляется вместе с остальными; уходя с прогулки, прячем его
  ModAPI.walkOn('hud', hud);
  ModAPI.walkOn('exit', function () { wkHudSet('mailarmor', ''); });

  // клавиша O на прогулке. WK_KEYS — общая таблица: не затираем чужой обработчик, а встаём в цепочку
  ModAPI.ready(function () {
    const prev = WK_KEYS.o;
    const f = function (e, k) {
      if (typeof prev === 'function' && prev(e, k) === true) return true;
      worn = !worn; hud();
      wkMsg(worn ? T('Вы надели кольчугу', 'You put on the mail') : T('Вы сняли кольчугу', 'You took off the mail'), worn ? 'good' : '');
      return true;   // клавиша взята
    };
    f.help = T('надеть или снять кольчугу', 'put on or take off the mail');   // строка в справке прогулки
    WK_KEYS.o = f;
  });
})();
